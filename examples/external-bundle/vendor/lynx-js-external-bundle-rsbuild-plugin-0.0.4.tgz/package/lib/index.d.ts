import type { RsbuildPlugin } from '@rsbuild/core';
import type { ExternalValue, ExternalsLoadingPluginOptions } from '@lynx-js/externals-loading-webpack-plugin';
/**
 * Options for the built-in `reactlynx` externals preset.
 *
 * @public
 */
export interface ReactLynxExternalsPresetOptions {
    /**
     * Emit the ReactLynx runtime bundle into the current build output and load it
     * through the generated runtime public path.
     *
     * Prefer this over `url` for normal Rspeedy projects. In addition to letting
     * the runtime resolve the final URL from `publicPath`, the plugin will also
     * copy the corresponding `@lynx-js/react-umd` bundle into the emitted assets,
     * so application bundles can reference it without requiring an extra manual
     * copy step when publishing.
     *
     * @defaultValue `'react.lynx.bundle'`
     */
    bundlePath?: string;
    /**
     * Override the runtime bundle URL directly.
     *
     * Use this only when the ReactLynx runtime is hosted outside the current
     * build output, for example on a CDN. Unlike `bundlePath`, this does not emit
     * any extra asset into the current compilation.
     *
     * @deprecated Prefer `bundlePath`, which resolves through the runtime public
     * path and enables automatic asset emission.
     */
    url?: string;
}
/**
 * Presets for external bundle dependencies.
 *
 * @public
 */
export interface ExternalsPresets {
    /**
     * Load the ReactLynx runtime bundle and wire its standard module globals.
     */
    reactlynx?: boolean | ReactLynxExternalsPresetOptions;
}
/**
 * Options for the external-bundle-rsbuild-plugin.
 *
 * @public
 */
export interface PluginExternalBundleOptions extends Pick<ExternalsLoadingPluginOptions, 'globalObject'> {
    /**
     * Root directory that stores project-owned external bundles referenced by
     * `bundlePath`.
     *
     * `pluginExternalBundle` uses this directory for both development serving
     * and build-time asset emission. Prefer setting this explicitly when
     * external bundles are built into a separate output folder, such as
     * `dist-external-bundle`.
     */
    externalBundleRoot?: string;
    /**
     * Additional explicit externals to load.
     */
    externals?: Record<string, PluginExternalValue>;
    /**
     * Built-in externals presets.
     */
    externalsPresets?: ExternalsPresets;
}
/**
 * External bundle reference accepted by `pluginExternalBundle`.
 *
 * @public
 */
export interface PluginExternalValue extends Omit<ExternalValue, 'url'> {
    /**
     * Bundle path resolved against the runtime public path.
     *
     * Prefer this over `url` when the external bundle should be emitted or served
     * as part of the current project. `pluginExternalBundle` can use this
     * information to manage local bundle files, while the runtime keeps the final
     * URL aligned with the active `publicPath`.
     */
    bundlePath?: string;
    /**
     * Bundle URL.
     *
     * Use this only when the external bundle lives outside the current build
     * output and should not be emitted or served by `pluginExternalBundle`.
     *
     * @deprecated Prefer `bundlePath`, which resolves through the runtime public
     * path and lets higher-level tooling manage asset emission.
     */
    url?: string;
}
/**
 * Create a rsbuild plugin for loading external bundles.
 *
 * This plugin wraps the externals-loading-webpack-plugin and automatically
 * retrieves layer names from the react-rsbuild-plugin via api.useExposed.
 *
 * @example
 * ```ts
 * // lynx.config.ts
 * import { pluginExternalBundle } from '@lynx-js/external-bundle-rsbuild-plugin'
 * import { pluginReactLynx } from '@lynx-js/react-rsbuild-plugin'
 *
 * export default {
 *   plugins: [
 *     pluginReactLynx(),
 *     pluginExternalBundle({
 *       externals: {
 *         lodash: {
 *           bundlePath: 'lodash.lynx.bundle',
 *           background: { sectionPath: 'background' },
 *           mainThread: { sectionPath: 'mainThread' },
 *         },
 *       },
 *     }),
 *   ],
 * }
 * ```
 *
 * @public
 */
export declare function pluginExternalBundle(options: PluginExternalBundleOptions): RsbuildPlugin;
