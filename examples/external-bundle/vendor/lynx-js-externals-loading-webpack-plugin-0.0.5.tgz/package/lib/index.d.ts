/**
 * @packageDocumentation
 *
 * A webpack plugin to load externals in Lynx. Use `lynx.fetchBundle()` and `lynx.loadScript()` API to load and parse the externals.
 *
 * @remarks
 * Requires Lynx version 3.5 or later.
 */
import type { Compiler } from '@rspack/core';
/**
 * The options of the `ExternalsLoadingPlugin`.
 *
 * @public
 */
export interface ExternalsLoadingPluginOptions {
    /**
     * The name of the main thread layer.
     */
    mainThreadLayer: string;
    /**
     * The name of the background layer.
     */
    backgroundLayer: string;
    /**
     * Specify the externals to be loaded. The externals should be Lynx Bundles.
     *
     * @example
     *
     * Load `lodash` library in background layer and `main-thread` layer.
     *
     * ```js
     * module.exports = {
     *  plugins: [
     *    new ExternalsLoadingPlugin({
     *      externals: {
     *        lodash: {
     *          url: 'http://lodash.lynx.bundle',
     *          background: { sectionPath: 'background' },
     *          mainThread: { sectionPath: 'mainThread' },
     *        },
     *      },
     *    }),
     *  ],
     * };
     * ```
     *
     * @example
     *
     * Load `lodash` library only in background layer.
     *
     * ```js
     * module.exports = {
     *  plugins: [
     *    new ExternalsLoadingPlugin({
     *      externals: {
     *        lodash: {
     *          url: 'http://lodash.lynx.bundle',
     *          background: { sectionPath: 'background' }
     *        },
     *      },
     *    }),
     *  ],
     * };
     * ```
     */
    externals: Record<string, ExternalValue>;
    /**
     * This option indicates what global object will be used to mount the library.
     *
     * In Lynx, the library will be mounted to `lynx[Symbol.for("__LYNX_EXTERNAL_GLOBAL__")]` by default.
     *
     * If you have enabled share js context and want to reuse the library by mounting to the global object, you can set this option to `'globalThis'`.
     *
     * @default 'lynx'
     */
    globalObject?: 'lynx' | 'globalThis' | undefined;
}
/**
 * The value item of the externals.
 *
 * @public
 */
export interface ExternalValue {
    /**
     * The final bundle URL to fetch directly at runtime.
     *
     * Use this when the external bundle is hosted outside the current build
     * output, such as on a CDN. If both `url` and `bundlePath` are provided,
     * `url` takes precedence because it is already the fully resolved address.
     */
    url?: string;
    /**
     * The bundle path resolved against the runtime public path.
     *
     * Prefer this over `url` when the bundle should follow the active
     * `publicPath`. The runtime will load it with `publicPath + bundlePath`,
     * which keeps external bundle resolution aligned with the current build
     * output without hard-coding an absolute URL into the generated runtime code.
     */
    bundlePath?: string;
    /**
     * The name of the library. Same as https://webpack.js.org/configuration/externals/#string.
     *
     * By default, the library name is the same as the externals key. For example:
     *
     * The config
     *
     * ```js
     * ExternalsLoadingPlugin({
     *   externals: {
     *     lodash: {
     *       url: '……',
     *     }
     *   }
     * })
     * ```
     *
     * Will generate the following webpack externals config:
     *
     * ```js
     * externals: {
     *   lodash: 'lynx[Symbol.for("__LYNX_EXTERNAL_GLOBAL__")].lodash',
     * }
     * ```
     *
     * If one external bundle contains multiple modules, should set the same library name to ensure it's loaded only once. For example:
     *
     * ```js
     * ExternalsLoadingPlugin({
     *   externals: {
     *     lodash: {
     *       libraryName: 'Lodash',
     *       url: '……',
     *     },
     *     'lodash-es': {
     *       libraryName: 'Lodash',
     *       url: '……',
     *     }
     *   }
     * })
     * ```
     * Will generate the following webpack externals config:
     *
     * ```js
     * externals: {
     *   lodash: 'lynx[Symbol.for("__LYNX_EXTERNAL_GLOBAL__")].Lodash',
     *   'lodash-es': 'lynx[Symbol.for("__LYNX_EXTERNAL_GLOBAL__")].Lodash',
     * }
     * ```
     *
     * You can pass an array to specify subpath of the external. Same as https://webpack.js.org/configuration/externals/#string-1. For example:
     *
     * ```js
     * ExternalsLoadingPlugin({
     *   externals: {
     *     preact: {
     *       libraryName: ['ReactLynx', 'Preact'],
     *       url: '……',
     *     },
     *   }
     * })
     * ```
     *
     * Will generate the following webpack externals config:
     *
     * ```js
     * externals: {
     *   preact: 'lynx[Symbol.for("__LYNX_EXTERNAL_GLOBAL__")].ReactLynx.Preact',
     * }
     * ```
     *
     * @defaultValue `undefined`
     *
     * @example `Lodash`
     */
    libraryName?: string | string[];
    /**
     * Whether the source should be loaded asynchronously or not.
     *
     * @defaultValue `true`
     */
    async?: boolean;
    /**
     * The options of the background layer.
     *
     * @defaultValue `undefined`
     */
    background?: LayerOptions;
    /**
     * The options of the main-thread layer.
     *
     * @defaultValue `undefined`
     */
    mainThread?: LayerOptions;
    /**
     * The wait time in milliseconds.
     *
     * @defaultValue `2000`
     */
    timeout?: number;
}
/**
 * The options of the background or main-thread layer.
 *
 * @public
 */
export interface LayerOptions {
    /**
     * The path in `customSections`.
     */
    sectionPath: string;
}
/**
 * The webpack plugin to load lynx external bundles.
 *
 * @example
 * ```js
 * // webpack.config.js
 * import { ExternalsLoadingPlugin } from '@lynx-js/externals-loading-webpack-plugin';
 *
 * export default {
 *   plugins: [
 *     new ExternalsLoadingPlugin({
 *       mainThreadLayer: 'main-thread',
 *       backgroundLayer: 'background',
 *       mainThreadChunks: ['index__main-thread'],
 *       backgroundChunks: ['index'],
 *       externals: {
 *        'lodash': {
 *          url: 'http://lodash.lynx.bundle',
 *          async: true,
 *          background: {
 *            sectionPath: 'background',
 *          },
 *          mainThread: {
 *            sectionPath: 'mainThread',
 *          },
 *        },
 *       }
 *     })
 *   ]
 * }
 * ```
 *
 * @public
 */
export declare class ExternalsLoadingPlugin {
    #private;
    private options;
    constructor(options: ExternalsLoadingPluginOptions);
    apply(compiler: Compiler): void;
}
