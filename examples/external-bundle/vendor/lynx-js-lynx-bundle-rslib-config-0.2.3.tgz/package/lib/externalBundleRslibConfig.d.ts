import type { LibConfig, RslibConfig } from '@rslib/core';
/**
 * The options for encoding the external bundle.
 *
 * @public
 */
export interface EncodeOptions {
    /**
     * The engine version of the external bundle.
     *
     * @defaultValue '3.5'
     */
    engineVersion?: string;
}
/**
 * The default lib config{@link LibConfig} for external bundle.
 *
 * @public
 */
export declare const defaultExternalBundleLibConfig: LibConfig;
export type Externals = Record<string, string | string[]>;
export interface ExternalsPresets {
    reactlynx?: boolean;
}
export type LibOutputConfig = Required<LibConfig>['output'];
export interface OutputConfig extends LibOutputConfig {
    /**
     * Presets for external libraries.
     *
     * Same as https://rspack.rs/config/externals#externalspresets but for Lynx.
     */
    externalsPresets?: ExternalsPresets;
    externals?: Externals;
    /**
     * This option indicates what global object will be used to mount the library.
     *
     * In Lynx, the library will be mounted to `lynx[Symbol.for("__LYNX_EXTERNAL_GLOBAL__")]` by default.
     *
     * If you have enabled share js context and want to reuse the library by mounting to the global object, you can set this option to `'globalThis'`.
     *
     * @default 'lynx'
     */
    globalObject?: 'lynx' | 'globalThis';
}
export interface ExternalBundleLibConfig extends LibConfig {
    output?: OutputConfig;
}
/**
 * Get the rslib config for building Lynx external bundles.
 *
 * @public
 *
 * @example
 *
 * If you want to build an external bundle which use in Lynx background thread, you can use the following code:
 *
 * ```js
 * // rslib.config.js
 * import { defineExternalBundleRslibConfig } from '@lynx-js/lynx-bundle-rslib-config'
 *
 * export default defineExternalBundleRslibConfig({
 *   id: 'utils-lib',
 *   source: {
 *     entry: {
 *       utils: {
 *         import: './src/utils.ts',
 *         layer: 'background',
 *       }
 *     }
 *   }
 * })
 * ```
 *
 * Then you can use `lynx.loadScript('utils', { bundleName: 'utils-lib-bundle-url' })` in background thread.
 *
 * @example
 *
 * If you want to build an external bundle which use in Lynx main thread, you can use the following code:
 *
 * ```js
 * // rslib.config.js
 * import { defineExternalBundleRslibConfig } from '@lynx-js/lynx-bundle-rslib-config'
 *
 * export default defineExternalBundleRslibConfig({
 *   id: 'utils-lib',
 *   source: {
 *     entry: {
 *       utils: {
 *         import: './src/utils.ts',
 *         layer: 'main-thread',
 *       }
 *     }
 *   }
 * })
 * ```
 * Then you can use `lynx.loadScript('utils', { bundleName: 'utils-lib-bundle-url' })` in main-thread.
 *
 * @example
 *
 * If you want to build an external bundle which use both in Lynx main thread and background thread. You don't need to set the layer.
 *
 * ```js
 * // rslib.config.js
 * import { defineExternalBundleRslibConfig } from '@lynx-js/lynx-bundle-rslib-config'
 *
 * export default defineExternalBundleRslibConfig({
 *   id: 'utils-lib',
 *   source: {
 *     entry: {
 *       utils: './src/utils.ts',
 *     },
 *   }
 * })
 * ```
 *
 * Then you can use `lynx.loadScript('utils', { bundleName: 'utils-lib-bundle-url' })` in background thread and `lynx.loadScript('utils__main-thread', { bundleName: 'utils-lib-bundle-url' })` in main-thread.
 */
export declare function defineExternalBundleRslibConfig(userLibConfig: ExternalBundleLibConfig, encodeOptions?: EncodeOptions): RslibConfig;
