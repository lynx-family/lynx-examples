import type { Compiler } from 'webpack';
/**
 * The options for {@link ExternalBundleWebpackPlugin}.
 *
 * @public
 */
export interface ExternalBundleWebpackPluginOptions {
    /**
     * The external bundle filename.
     *
     * @example
     * ```js
     * new ExternalBundleWebpackPlugin({
     *   bundleFileName: 'lib.lynx.bundle'
     * })
     * ```
     */
    bundleFileName: string;
    /**
     * The encode method which is exported from lynx-tasm package.
     *
     * @example
     * ```js
     * import { getEncodeMode } from '@lynx-js/tasm';
     *
     * new ExternalBundleWebpackPlugin({
     *   encode: getEncodeMode()
     * })
     * ```
     */
    encode: (opts: unknown) => Promise<{
        buffer: Buffer;
    }>;
    /**
     * The engine version of the external bundle.
     *
     * @defaultValue '3.5'
     */
    engineVersion?: string | undefined;
}
/**
 * The webpack plugin to build and emit the external bundle.
 *
 * @public
 */
export declare class ExternalBundleWebpackPlugin {
    #private;
    private options;
    constructor(options: ExternalBundleWebpackPluginOptions);
    apply(compiler: Compiler): void;
}
