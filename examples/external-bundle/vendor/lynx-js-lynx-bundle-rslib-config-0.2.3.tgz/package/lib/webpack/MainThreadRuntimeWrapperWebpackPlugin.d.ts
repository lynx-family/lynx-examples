import type { BannerPlugin, Compiler } from 'webpack';
/**
 * The options of {@link MainThreadRuntimeWrapperWebpackPlugin}.
 *
 * @public
 */
export interface MainThreadRuntimeWrapperWebpackPluginOptions {
    /**
     * Include all modules that pass test assertion.
     *
     * @defaultValue `/\.js$/`
     *
     * @public
     */
    test: BannerPlugin['options']['test'];
}
/**
 * The main-thread runtime wrapper for external bundle.
 *
 * @public
 */
export declare class MainThreadRuntimeWrapperWebpackPlugin {
    private options;
    constructor(options?: Partial<MainThreadRuntimeWrapperWebpackPluginOptions>);
    apply(compiler: Compiler): void;
}
